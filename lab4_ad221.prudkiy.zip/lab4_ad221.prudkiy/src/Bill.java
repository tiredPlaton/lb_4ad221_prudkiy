import java.util.List;
import java.util.ArrayList;
public class Bill {
    protected List<Item> items;

    public Bill() {
        this.items = new ArrayList<>();
    }

    public void addItem(Item item) {
        this.items.add(item);
    }

    public double getTotal() {
        double total = 0;
        for (Item item : items) {
            total += item.getPrice();
        }
        return total;
    }
}
