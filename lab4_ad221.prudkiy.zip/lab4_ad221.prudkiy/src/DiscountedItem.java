public class DiscountedItem extends Item {
    private final double discount;

    public DiscountedItem(String name, double price, double discount) {
        super(name, price);
        this.discount = discount;
    }

    public double getDiscount() {
        return discount;
    }
}

