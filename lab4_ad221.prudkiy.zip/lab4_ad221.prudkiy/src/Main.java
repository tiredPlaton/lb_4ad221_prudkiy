
public class Main {
    public static void main(String[] args) {
        // Створення нових товарів
        DiscountedItem apple = new DiscountedItem("Apple", 1.0, 0.1);
        DiscountedItem orange = new DiscountedItem("Orange", 2.0, 0.2);
        DiscountedItem banana = new DiscountedItem("Banana", 1.5, 0.15);
        DiscountedItem pineapple = new DiscountedItem("Pineapple", 3.0, 0.3);
        DiscountedItem grapes = new DiscountedItem("Grapes", 2.5, 0);

        // Створення нового рахунку для постійного клієнта
        RegularCustomerBill bill = new RegularCustomerBill();

        // Додавання товарів до рахунку
        bill.addItem(apple);
        bill.addItem(orange);
        bill.addItem(banana);
        bill.addItem(pineapple);
        bill.addItem(grapes);

        // Виведення інформації про рахунок
        System.out.println("Total: " + bill.getTotal());
        System.out.println("Number of discounted items: " + bill.getDiscountedItemsCount());
        System.out.println("Total discount: " + bill.getTotalDiscount());
    }
}