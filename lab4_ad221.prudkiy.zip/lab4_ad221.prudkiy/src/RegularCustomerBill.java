
public class RegularCustomerBill extends Bill {

    @Override
    public void addItem(Item item) {
        if (item instanceof DiscountedItem) {
            this.items.add(item);
        } else {
            throw new IllegalArgumentException("Only discounted items can be added to a regular customer's bill");
        }
    }

    @Override
    public double getTotal() {
        double total = 0;
        for (Item item : items) {
            if (item instanceof DiscountedItem) {
                total += item.getPrice() - ((DiscountedItem) item).getDiscount();
            } else {
                total += item.getPrice();
            }
        }
        return total;
    }

    public int getDiscountedItemsCount() {
        int count = 0;
        for (Item item : items) {
            if (item instanceof DiscountedItem && ((DiscountedItem) item).getDiscount() > 0) {
                count++;
            }
        }
        return count;
    }

    public double getTotalDiscount() {
        double totalDiscount = 0;
        for (Item item : items) {
            if (item instanceof DiscountedItem && ((DiscountedItem) item).getDiscount() > 0) {
                totalDiscount += ((DiscountedItem) item).getDiscount();
            }
        }
        return totalDiscount;
    }
}